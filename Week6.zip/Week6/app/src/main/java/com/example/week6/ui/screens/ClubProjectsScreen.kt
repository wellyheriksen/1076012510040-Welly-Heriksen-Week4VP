package com.example.week6.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.week6.ui.theme.Week6Theme
import com.example.week6.viewmodel.CampusViewModel

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ClubProjectsScreen(
    communityId: String,
    vm: CampusViewModel,
    onBackClick: () -> Unit,
    onNavigateToProjectDetail: (String) -> Unit
) {
    val communities by vm.communities.collectAsState()
    val projects by vm.projects.collectAsState()

    val community = communities.find { it.id == communityId }
    val clubProjects = projects.filter { it.communityId == communityId }

    var showDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("${community?.name ?: "Club"} Projects", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showDialog = true }) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add Project")
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (clubProjects.isEmpty()) {
                Text(
                    text = "Belum ada proyek di komunitas ini",
                    color = Color.Gray,
                    modifier = Modifier.align(Alignment.Center)
                )
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(clubProjects, key = { it.id }) { proj ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onNavigateToProjectDetail(proj.id) },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = proj.title,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = proj.desc,
                                        fontSize = 14.sp,
                                        color = Color.Gray
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    FlowRow(
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        proj.techStack.forEach { tech ->
                                            AssistChip(
                                                onClick = { },
                                                label = { Text(tech, fontSize = 10.sp) }
                                            )
                                        }
                                    }
                                }
                                IconButton(onClick = { vm.deleteProject(proj.id) }) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showDialog) {
            AddProjectDialog(
                onDismiss = { showDialog = false },
                onSave = { title, desc, techStack ->
                    vm.addProject(communityId, title, desc, techStack)
                    showDialog = false
                }
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddProjectDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, List<String>) -> Unit
) {
    var title by rememberSaveable { mutableStateOf("") }
    var desc by rememberSaveable { mutableStateOf("") }
    val selectedTech = remember { mutableStateListOf<String>() }

    val techOptions = listOf("Kotlin", "Jetpack Compose", "Firebase", "Ktor", "Room", "Python")

    val isFormValid = title.isNotBlank() && desc.isNotBlank() && selectedTech.isNotEmpty()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Project", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Judul Proyek") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text("Deskripsi") },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Tech Stack:", fontWeight = FontWeight.Medium, fontSize = 14.sp)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    techOptions.forEach { tech ->
                        val isSelected = selectedTech.contains(tech)
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                if (isSelected) selectedTech.remove(tech) else selectedTech.add(tech)
                            },
                            label = { Text(tech) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (isFormValid) {
                        onSave(title, desc, selectedTech.toList())
                    }
                },
                enabled = isFormValid
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Preview(showBackground = true)
@Composable
fun ClubProjectsScreenPreview() {
    val vm = remember { CampusViewModel() }
    Week6Theme {
        ClubProjectsScreen(
            communityId = "c1",
            vm = vm,
            onBackClick = {},
            onNavigateToProjectDetail = {}
        )
    }
}
