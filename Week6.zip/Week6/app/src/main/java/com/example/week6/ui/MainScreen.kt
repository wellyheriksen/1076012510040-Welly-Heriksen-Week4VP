package com.example.week6.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.week6.navigation.ClubProjectsRoute
import com.example.week6.navigation.CommunitiesRoute
import com.example.week6.navigation.DashboardRoute
import com.example.week6.navigation.ProjectDetailRoute
import com.example.week6.ui.screens.ClubProjectsScreen
import com.example.week6.ui.screens.CommunitiesScreen
import com.example.week6.ui.screens.DashboardScreen
import com.example.week6.ui.screens.ProjectDetailScreen
import com.example.week6.ui.theme.Week6Theme
import com.example.week6.viewmodel.CampusViewModel

@Composable
fun MainScreen(vm: CampusViewModel = viewModel()) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    val isDetailScreen = currentDestination?.hierarchy?.any {
        it.route?.contains("ClubProjectsRoute") == true || it.route?.contains("ProjectDetailRoute") == true
    } == true

    val showBottomBar = !isDetailScreen

    val isCommunitiesSelected = currentDestination?.hierarchy?.any {
        it.route?.contains("CommunitiesRoute") == true
    } == true

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    NavigationBarItem(
                        selected = !isCommunitiesSelected,
                        onClick = {
                            navController.navigate(DashboardRoute) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(Icons.Default.Person, contentDescription = "Dashboard") },
                        label = { Text("Dashboard") }
                    )
                    NavigationBarItem(
                        selected = isCommunitiesSelected,
                        onClick = {
                            navController.navigate(CommunitiesRoute) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(Icons.Default.Group, contentDescription = "Communities") },
                        label = { Text("Communities") }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = DashboardRoute,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable<DashboardRoute> {
                DashboardScreen(vm = vm)
            }
            composable<CommunitiesRoute> {
                CommunitiesScreen(
                    vm = vm,
                    onNavigateToDetail = { communityId ->
                        navController.navigate(ClubProjectsRoute(communityId))
                    }
                )
            }
            composable<ClubProjectsRoute> { backStackEntry ->
                val route: ClubProjectsRoute = backStackEntry.toRoute()
                ClubProjectsScreen(
                    communityId = route.communityId,
                    vm = vm,
                    onBackClick = { navController.popBackStack() },
                    onNavigateToProjectDetail = { projectId ->
                        navController.navigate(ProjectDetailRoute(projectId))
                    }
                )
            }
            composable<ProjectDetailRoute> { backStackEntry ->
                val route: ProjectDetailRoute = backStackEntry.toRoute()
                ProjectDetailScreen(
                    projectId = route.projectId,
                    vm = vm,
                    onBackClick = { navController.popBackStack() }
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun MainScreenPreview() {
    Week6Theme {
        MainScreen()
    }
}
