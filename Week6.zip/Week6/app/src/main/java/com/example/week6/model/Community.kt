package com.example.week6.model

data class Community(
    val id: String,
    val name: String,
    val desc: String,
    val isJoined: Boolean = false
)
