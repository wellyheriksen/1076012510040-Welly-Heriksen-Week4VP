package com.example.week6.viewmodel

import androidx.lifecycle.ViewModel
import com.example.week6.model.Community
import com.example.week6.model.Project
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class CampusViewModel : ViewModel() {

    val name = "Welly Heriksen"
    val major = "Teknik Informatika 2025"

    private val _communities = MutableStateFlow(
        listOf(
            Community("c1", "GDSC", "Google Developer Student Club"),
            Community("c2", "CyberSecurity Guild", "Komunitas Keamanan Siber"),
            Community("c3", "AI Society", "Membahas Kecerdasan Buatan"),
            Community("c4", "Mobile Dev Club", "Pengembangan App Mobile"),
            Community("c5", "Game Dev Club", "Pembuatan Game & Graphics"),
            Community("c6", "Web Dev Club", "Pengembangan Web Modern")
        )
    )
    val communities: StateFlow<List<Community>> = _communities.asStateFlow()

    private val _projects = MutableStateFlow(
        listOf(
            Project(
                id = "p1",
                communityId = "c1",
                title = "Campus App",
                desc = "Aplikasi kampus sederhana",
                techStack = listOf("Kotlin", "Jetpack Compose"),
                status = "In Progress"
            )
        )
    )
    val projects: StateFlow<List<Project>> = _projects.asStateFlow()

    fun toggleJoin(id: String) {
        _communities.update { list ->
            list.map { item ->
                if (item.id == id) item.copy(isJoined = !item.isJoined) else item
            }
        }
    }

    fun addProject(communityId: String, title: String, desc: String, techStack: List<String>) {
        val newProj = Project(
            id = System.currentTimeMillis().toString(),
            communityId = communityId,
            title = title,
            desc = desc,
            techStack = techStack,
            status = "In Progress"
        )
        _projects.update { it + newProj }
    }

    fun deleteProject(projectId: String) {
        _projects.update { list ->
            list.filterNot { it.id == projectId }
        }
    }

    fun toggleProjectStatus(projectId: String) {
        _projects.update { list ->
            list.map { item ->
                if (item.id == projectId) {
                    val newStatus = if (item.status == "In Progress") "Completed" else "In Progress"
                    item.copy(status = newStatus)
                } else item
            }
        }
    }
}
