package com.example.week6.model

data class Project(
    val id: String,
    val communityId: String,
    val title: String,
    val desc: String,
    val techStack: List<String>,
    val status: String = "In Progress"
)
